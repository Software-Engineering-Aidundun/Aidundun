# This is a wechat-miniprogram named Aidundun,which is also our group's course project of software engineering.
